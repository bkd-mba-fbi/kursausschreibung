# Get Started

## Try it out

Use this area to play with the editor and get to grips with some of the content blocks. Have a play then move on to the next page!

{% embed url="https://www.youtube.com/playlist?list=PLLDtLiOuctbxh5lSRpjZqJI9IPbpY7A-3" %}
FBI Playlist
{% endembed %}

## Moving on

All good? Let's explore some of the main GitBook concepts, starting with **Spaces**.
